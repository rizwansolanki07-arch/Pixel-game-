# `src/mobile/` — the offline / Android build of Pixel Quest

Everything needed to ship the game as a **standalone offline app** (and as an
installable **PWA**) instead of the perchance generator page. Nothing in here is
loaded by the generator at runtime — it is a build tool + app source.

```
src/mobile/
  build.mjs                 the builder (Node 18+, uses `npx esbuild` on demand)
  index.template.html       the standalone page shell (canvas + boot overlay + CSS)
  manifest.webmanifest      PWA manifest (icons, fullscreen, landscape)
  sw.js                     service worker: caches the app shell for offline use
  icons/                    64 / 192 / 512 / maskable-512 icons (generated from the
                            game's own pixel art via a canvas in the browser)
  START-HERE.md             user-facing instructions (ships inside the zip)
  android/                  a complete Android Studio project (WebView shell)
    app/src/main/assets/index.html   ← THE BUILT GAME (generated, ~510 KB)
    app/src/main/java/.../MainActivity.java
    app/src/main/res/...              launcher icons, theme, strings
    ci/build-apk.yml                  GitHub Actions workflow (move to
                                      .github/workflows/ when you push the project)
```

## Building

```bash
node src/mobile/build.mjs                 # writes android/app/src/main/assets/index.html
node src/mobile/build.mjs --out web/       # + a hostable PWA folder
node src/mobile/build.mjs --minify         # smaller output
```

`build.mjs` bundles `src/main.js` with esbuild (`format=esm`, `target=esnext`) and
inlines the result plus the six atlas PNGs (as `data:` URLs via
`window.PQ_ASSET_URLS`) into one self-contained HTML file. `src/art/assets.js`
reads that map first and falls back to the normal `src/art/assets/` paths, so the
generator page is completely unaffected.

**Rebuild whenever anything under `src/` changes** — the committed
`android/app/src/main/assets/index.html` is a build artifact and will otherwise go
stale. (The workspace `scratch/` is ephemeral; the built file in `android/` is the
durable copy that keeps the project buildable with no Node/esbuild.)

`target=esnext` is deliberate: `src/main.js` uses a top-level `await` so the first
frame already uses the supplied atlases. That means the app needs a WebView/Chrome
from 2021+ (WebView 89+), i.e. Android 7+ with an updated Android System WebView.

## Why it is built this way

- **One self-contained HTML file** works from `file://` (so it can be opened
  straight from a phone's Downloads folder), inside an Android WebView, and on any
  static host — no server, no relative-path or CORS problems, no module loading.
- The APK's WebView therefore needs no `WebViewAssetLoader`, no androidx dependency
  and no INTERNET permission: `file:///android_asset/index.html` is all it loads.
- The same file is the PWA's `index.html`, so there is one payload to keep correct.

## Hosting notes (what was tried and what works)

- `upload_file` / the perchance file host **rejects `.html`** (`invalid_filetype`)
  and serves unknown extensions as `text/plain`, so it cannot host the app page.
  It happily serves `.js` (`text/javascript`), `.json`, `.png`, `.svg`.
- `uploadPlugin.editable` gives stable, predictable URLs, but it is text/plain and
  requires a *saved* generator, so it cannot host a service worker either.
- A service worker must be same-origin with the page, so the PWA has to be hosted
  somewhere that serves real HTML (GitHub Pages / Netlify / any static host). Once
  it is, Chrome on Android mints a real installable WebAPK from the manifest —
  no build tools needed on the phone.

## Android project

`android/` has zero library dependencies (no androidx, no bundles), `minSdk 24`,
`targetSdk 34`, Java 17, AGP 8.5.2, Gradle 8.7 (wrapper included). The release
build type is signed with the debug key so `./gradlew assembleRelease` produces an
installable APK with no keystore setup.

`app/src/main/AndroidManifest.xml` declares **no permissions**; the activity is
locked to landscape, immersive (system bars hidden), keeps the screen on, and
pauses/resumes the WebView with the app lifecycle.
