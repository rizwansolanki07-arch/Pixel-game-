#!/usr/bin/env node
/**
 * Pixel Quest — offline / mobile app builder.
 *
 * Produces a SINGLE self-contained HTML file (index.html) that runs the whole
 * game with no network, no server and no perchance engine: the bundled game code
 * is inlined as a <script type="module">, and every atlas PNG is inlined as a
 * data URL (window.PQ_ASSET_URLS). That file is what ships inside the Android
 * app (app/src/main/assets/index.html) and it is also the file you host if you
 * want an installable PWA (together with manifest.webmanifest + sw.js + icons).
 *
 * Usage (from the generator workspace root):
 *
 *   node src/mobile/build.mjs                  # build into the Android assets dir
 *   node src/mobile/build.mjs --out web/       # also emit a hostable web app
 *   node src/mobile/build.mjs --minify         # smaller output
 *
 * Requires Node 18+; esbuild is fetched on demand with `npx --yes esbuild@0.21.5`.
 * Rebuild this whenever anything under src/ changes.
 */
import { execFileSync } from "node:child_process";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, "..", "..");
const args = process.argv.slice(2);
const has = (n) => args.includes("--" + n);
const opt = (n, dflt) => {
  const i = args.indexOf("--" + n);
  return i >= 0 && args[i + 1] && !args[i + 1].startsWith("--") ? args[i + 1] : dflt;
};

const ESBUILD = opt("esbuild", "esbuild@0.21.5");
const ATLASES = ["kiro.png", "slime.png", "bee.png", "bee2.png", "terrain.png", "props.png"];
const WEB_FILES = ["manifest.webmanifest", "sw.js"];
const WEB_ICONS = ["icon-64.png", "icon-192.png", "icon-512.png", "maskable-512.png"];

function bundle(minify) {
  const tmp = path.join(os.tmpdir(), `pixelquest-bundle-${process.pid}.js`);
  const argv = [
    "--yes", ESBUILD,
    path.join(root, "src/main.js"),
    // esnext keeps the top-level `await` in src/main.js intact - it is what lets the
    // first frame already use the supplied pixel-art atlases.
    "--bundle", "--format=esm", "--target=esnext", "--platform=browser",
    "--legal-comments=none", "--log-level=warning",
    "--outfile=" + tmp,
  ];
  if (minify) argv.push("--minify");
  console.log("• bundling src/main.js with " + ESBUILD + (minify ? " (minified)" : ""));
  execFileSync("npx", argv, { cwd: root, stdio: "inherit" });
  const code = fs.readFileSync(tmp, "utf8");
  fs.rmSync(tmp, { force: true });
  return code;
}

function assetMap() {
  const map = {};
  for (const name of ATLASES) {
    const p = path.join(root, "src/art/assets", name);
    map[name] = "data:image/png;base64," + fs.readFileSync(p).toString("base64");
  }
  return map;
}

function buildPage(minify) {
  const tpl = fs.readFileSync(path.join(here, "index.template.html"), "utf8");
  const html = tpl
    .replace("{{ASSET_MAP}}", JSON.stringify(assetMap()))
    .replace("{{GAME_BUNDLE}}", () => bundle(minify));
  return html;
}

function writeWebApp(html, outDir) {
  fs.mkdirSync(path.join(outDir, "icons"), { recursive: true });
  fs.writeFileSync(path.join(outDir, "index.html"), html);
  for (const f of WEB_FILES) fs.copyFileSync(path.join(here, f), path.join(outDir, f));
  for (const f of WEB_ICONS) fs.copyFileSync(path.join(here, "icons", f), path.join(outDir, "icons", f));
  console.log("• web app written to " + path.relative(root, outDir));
}

const html = buildPage(has("minify"));
console.log(`• index.html: ${(Buffer.byteLength(html) / 1024).toFixed(0)} KB`);

const androidAssets = opt("android-assets", path.join(here, "android/app/src/main/assets"));
fs.mkdirSync(androidAssets, { recursive: true });
fs.writeFileSync(path.join(androidAssets, "index.html"), html);
console.log("• android assets written to " + path.relative(root, androidAssets));

const outDir = opt("out", null);
if (outDir) writeWebApp(html, path.resolve(root, outDir));

console.log("done.");
